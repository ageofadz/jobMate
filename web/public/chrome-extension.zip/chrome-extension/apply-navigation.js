function trimTrailingSlashes(path) {
  let p = String(path || "");
  while (p.length > 1 && p.charAt(p.length - 1) === "/") {
    p = p.slice(0, -1);
  }
  return p || "/";
}

function isDigitChar(ch) {
  const code = ch.charCodeAt(0);
  return code >= 48 && code <= 57;
}

function isHexChar(ch) {
  const code = ch.charCodeAt(0);
  return (code >= 48 && code <= 57) || (code >= 97 && code <= 102) || (code >= 65 && code <= 70);
}

function isDigitRun(value, minLen) {
  const s = String(value || "");
  if (s.length < minLen) return false;
  for (let i = 0; i < s.length; i++) {
    if (!isDigitChar(s.charAt(i))) return false;
  }
  return true;
}

function extractLongestDigitRun(value, minLen) {
  const s = String(value || "");
  let best = "";
  let run = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s.charAt(i);
    if (isDigitChar(ch)) {
      run += ch;
    } else if (run.length >= minLen && run.length > best.length) {
      best = run;
      run = "";
    } else {
      run = "";
    }
  }
  if (run.length >= minLen && run.length > best.length) best = run;
  return best;
}

function isUuidToken(token) {
  const parts = String(token || "").split("-");
  if (parts.length !== 5) return false;
  const lens = [8, 4, 4, 4, 12];
  for (let i = 0; i < 5; i++) {
    if (parts[i].length !== lens[i]) return false;
    for (let j = 0; j < parts[i].length; j++) {
      if (!isHexChar(parts[i].charAt(j))) return false;
    }
  }
  return true;
}

function normalizeApplyScopeUrl(url, baseUrl) {
  try {
    const parsed = new URL(url, baseUrl || undefined);
    parsed.hash = "";
    const path = trimTrailingSlashes(parsed.pathname);
    return `${parsed.origin}${path}${parsed.search}`;
  } catch {
    return String(url || "").trim();
  }
}

function extractJobUrlIdentifiers(url, baseUrl) {
  const ids = new Set();
  try {
    const parsed = new URL(url, baseUrl || undefined);
    const segments = parsed.pathname.split("/");
    for (const seg of segments) {
      if (!seg) continue;
      const dot = seg.lastIndexOf(".");
      const base = dot > 0 ? seg.slice(0, dot) : seg;
      if (isDigitRun(base, 5)) ids.add(base);
      const run = extractLongestDigitRun(base, 5);
      if (run) ids.add(run);
      if (isUuidToken(base)) ids.add(base.toLowerCase());
      if (isUuidToken(seg)) ids.add(seg.toLowerCase());
    }
    for (const value of parsed.searchParams.values()) {
      if (isDigitRun(value, 5)) ids.add(value);
      const run = extractLongestDigitRun(value, 5);
      if (run) ids.add(run);
      if (isUuidToken(value)) ids.add(value.toLowerCase());
    }
  } catch { }
  return ids;
}

function htmlStemParentPrefix(path) {
  const trimmed = trimTrailingSlashes(path);
  const slash = trimmed.lastIndexOf("/");
  const leaf = slash >= 0 ? trimmed.slice(slash + 1) : trimmed;
  const dot = leaf.lastIndexOf(".");
  if (dot <= 0) return null;
  if (leaf.slice(dot + 1).toLowerCase() !== "html") return null;
  return trimmed.slice(0, trimmed.length - (leaf.length - dot)) + "/";
}

function pathPrefixRelationship(pathA, pathB) {
  const a = trimTrailingSlashes(pathA);
  const b = trimTrailingSlashes(pathB);
  if (a === b) return true;
  const bPrefix = b + "/";
  const aPrefix = a + "/";
  if (a.length > b.length && a.slice(0, bPrefix.length) === bPrefix) return true;
  if (b.length > a.length && b.slice(0, aPrefix.length) === aPrefix) return true;
  const aStemPrefix = htmlStemParentPrefix(a);
  if (aStemPrefix && b.startsWith(aStemPrefix) && b !== a) return true;
  const bStemPrefix = htmlStemParentPrefix(b);
  if (bStemPrefix && a.startsWith(bStemPrefix) && a !== b) return true;
  return false;
}

function resolveActionUrl(href, pageUrl) {
  try {
    return new URL(href, pageUrl).toString();
  } catch {
    return "";
  }
}

function listingStemPrefixes(applyAnchorUrls, pageUrl) {
  const stems = new Set();
  for (const raw of applyAnchorUrls) {
    if (!raw) continue;
    try {
      const path = trimTrailingSlashes(new URL(raw, pageUrl).pathname);
      const stem = htmlStemParentPrefix(path);
      if (stem) stems.add(stem);
    } catch { }
  }
  return stems;
}

function isStemChildApplyPath(resolvedUrl, applyAnchorUrls, pageUrl) {
  if (!resolvedUrl) return false;
  try {
    const path = trimTrailingSlashes(new URL(resolvedUrl, pageUrl).pathname);
    for (const stem of listingStemPrefixes(applyAnchorUrls, pageUrl)) {
      if (path.startsWith(stem) && path.length > stem.length) return true;
    }
  } catch { }
  return false;
}

function resolveStemChildActionUrl(action, applyAnchorUrls, pageUrl) {
  const href = action?.href || action?.url || "";
  if (!href) return "";
  const resolved = resolveActionUrl(href, pageUrl);
  if (!resolved || !isStemChildApplyPath(resolved, applyAnchorUrls, pageUrl)) return "";
  return resolved;
}

function actionScopeTier(action, applyAnchorUrls, pageUrl) {
  const href = action.href || action.url || "";
  if (!href) return 3;
  const resolved = resolveActionUrl(href, pageUrl);
  if (!resolved) return 4;
  const pageNorm = normalizeApplyScopeUrl(pageUrl, pageUrl);
  const resolvedNorm = normalizeApplyScopeUrl(resolved, pageUrl);
  if (!isSameJobApplyScope(resolved, applyAnchorUrls, pageUrl)) return 4;
  if (resolvedNorm !== pageNorm) return 1;
  return 2;
}

function prioritizeA11yActions(actions, applyAnchorUrls, pageUrl) {
  return [...actions].sort((a, b) => actionScopeTier(a, applyAnchorUrls, pageUrl) - actionScopeTier(b, applyAnchorUrls, pageUrl));
}

function prioritizeActionsForClassifier(actions, applyAnchorUrls, pageUrl, maxCount) {
  const tiers = [[], [], [], []];
  for (const action of actions) {
    const tierIndex = actionScopeTier(action, applyAnchorUrls, pageUrl) - 1;
    if (tierIndex >= 0 && tierIndex < 4) tiers[tierIndex].push(action);
    else tiers[3].push(action);
  }
  const out = [];
  for (const tier of tiers) {
    for (const action of tier) {
      if (out.length >= maxCount) return out;
      out.push(action);
    }
  }
  return out;
}

function rankScopedApplyAdvancingActions(actions, applyAnchorUrls, pageUrl, guardFail) {
  const pageNorm = normalizeApplyScopeUrl(pageUrl, pageUrl);
  const candidates = [];
  for (const action of actions) {
    if (guardFail(action)) continue;
    const href = action.href || action.url || "";
    if (!href) continue;
    const resolved = resolveActionUrl(href, pageUrl);
    if (!resolved) continue;
    if (normalizeApplyScopeUrl(resolved, pageUrl) === pageNorm) continue;
    if (!isSameJobApplyScope(resolved, applyAnchorUrls, pageUrl)) continue;
    if (!isStemChildApplyPath(resolved, applyAnchorUrls, pageUrl)) continue;
    let pathLen = 0;
    try {
      pathLen = trimTrailingSlashes(new URL(resolved, pageUrl).pathname).length;
    } catch { }
    candidates.push({ elementId: action.elementId, pathLen });
  }
  candidates.sort((a, b) => b.pathLen - a.pathLen);
  const out = [];
  for (const candidate of candidates) {
    if (!out.includes(candidate.elementId)) out.push(candidate.elementId);
  }
  return out;
}

function resolveApplyAnchorUrls(anchorUrls, baseUrl) {
  const anchors = [];
  for (const raw of anchorUrls) {
    if (!raw) continue;
    try {
      anchors.push(new URL(raw, baseUrl));
    } catch { }
  }
  return anchors;
}

function identifierOverlap(candidateIds, anchorIdsList) {
  for (const anchorIds of anchorIdsList) {
    for (const id of candidateIds) {
      if (anchorIds.has(id)) return true;
    }
  }
  return false;
}

function isSameJobApplyScope(candidateUrl, anchorUrls, baseUrl) {
  if (!candidateUrl) return false;
  const anchors = resolveApplyAnchorUrls(anchorUrls, baseUrl);
  if (!anchors.length) return true;

  const candidateNorm = normalizeApplyScopeUrl(candidateUrl, baseUrl);
  try {
    const candidate = new URL(candidateUrl, baseUrl);
    const candidateIds = extractJobUrlIdentifiers(candidateUrl, baseUrl);

    for (const anchor of anchors) {
      const anchorNorm = normalizeApplyScopeUrl(anchor.toString(), baseUrl);
      if (candidateNorm === anchorNorm) return true;

      if (candidate.origin === anchor.origin) {
        const cPath = trimTrailingSlashes(candidate.pathname);
        const aPath = trimTrailingSlashes(anchor.pathname);
        if (pathPrefixRelationship(cPath, aPath)) return true;
      }

      const anchorIds = extractJobUrlIdentifiers(anchor.toString(), baseUrl);
      if (candidateIds.size && anchorIds.size) {
        for (const id of candidateIds) {
          if (anchorIds.has(id)) return true;
        }
      }
    }
  } catch { }
  return false;
}

function isOffTargetJobUrl(candidateUrl, anchorUrls, baseUrl) {
  if (!candidateUrl) return false;
  if (isSameJobApplyScope(candidateUrl, anchorUrls, baseUrl)) return false;

  try {
    const anchors = resolveApplyAnchorUrls(anchorUrls, baseUrl);
    const candidateIds = extractJobUrlIdentifiers(candidateUrl, baseUrl);
    if (candidateIds.size > 0) {
      const anchorIdsList = anchors.map((anchor) => extractJobUrlIdentifiers(anchor.toString(), baseUrl));
      if (!identifierOverlap(candidateIds, anchorIdsList)) return true;
    }
  } catch { }
  return false;
}

function isReturnToListingUrl(candidateUrl, listingUrl, baseUrl) {
  if (!candidateUrl || !listingUrl) return false;
  return normalizeApplyScopeUrl(candidateUrl, baseUrl) === normalizeApplyScopeUrl(listingUrl, baseUrl);
}

function isAllowedNavigateUrl(url, baseUrl, pageHost, targetApplyUrl, hiddenApplyUrl, hasLeftTargetListing) {
  if (hasLeftTargetListing && targetApplyUrl && isReturnToListingUrl(url, targetApplyUrl, baseUrl)) {
    return false;
  }
  const anchors = [targetApplyUrl, hiddenApplyUrl].filter(Boolean);
  if (!anchors.length) {
    return true;
  }
  return isSameJobApplyScope(url, anchors, baseUrl);
}
